=== Zakat Calculator ===
Contributors: mkshishir
Tags: zakat,charity,calculation
Requires at least: 5.3
Tested up to: 6.4.3
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Text Domain: zakat-calculator-elementor

The Zakat Calculator Elementor widget is a simple tool designed to help users calculate Zakat conveniently within their Elementor-powered WordPress website. This documentation provides an overview of the plugin's features, installation instructions, customization options, and usage guide.


